<?php
/**
 * The template for displaying scrolling top
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package dineshghimire
 * @subpackage blogmagazine
 * @since 1.0.7
 */
?>
<div id="blogmagazine-scrollup" class="animated arrow-hide">
	<i class="fa fa-chevron-up"></i>
</div>
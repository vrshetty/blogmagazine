<?php
/*
 * Panel Colors
 */
require_once blogmagazine_file_directory( 'inc/customizer/colors/section-theme-color.php' );
require_once blogmagazine_file_directory( 'inc/customizer/colors/section-category-color.php' );

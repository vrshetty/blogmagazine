<?php
/**
 * The customizer file for Footer Settings
 *
 * @package dineshghimire
 * @subpackage blogmagazine
 * @since 1.0.0
 */

require_once blogmagazine_file_directory( 'inc/customizer/footer/section-footer-main.php' );
require_once blogmagazine_file_directory( 'inc/customizer/footer/section-footer-info.php' );

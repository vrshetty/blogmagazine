<?php
/*
 * Panel Templates
 */
require_once blogmagazine_file_directory( 'inc/customizer/templates/templates-homepage.php' );
require_once blogmagazine_file_directory( 'inc/customizer/templates/templates-post-details.php' );
require_once blogmagazine_file_directory( 'inc/customizer/templates/templates-page-details.php' );
require_once blogmagazine_file_directory( 'inc/customizer/templates/templates-archive.php' );
require_once blogmagazine_file_directory( 'inc/customizer/templates/templates-blog-page.php' );
require_once blogmagazine_file_directory( 'inc/customizer/templates/templates-search-page.php' );
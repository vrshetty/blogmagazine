<?php
/*
 * Panel Options
 */
require_once blogmagazine_file_directory( 'inc/customizer/options/section-website-layout.php' );
require_once blogmagazine_file_directory( 'inc/customizer/options/section-image-settings.php' );
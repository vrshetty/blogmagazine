<?php
/*
 * Front Reaction Section
 */
require_once dglib_file_directory('sections/dg-front-reaction-section.php');
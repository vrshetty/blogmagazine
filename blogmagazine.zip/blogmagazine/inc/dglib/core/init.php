<?php

/*
 * Include core functions
 */
require_once dglib_file_directory('core/functions.php');

/*
 * Include sanitize customizer functions
 */
require_once dglib_file_directory('core/sanitize-customizer.php');


/*
 * Include sanitize widget functions
 */
require_once dglib_file_directory('core/sanitize-widget.php');

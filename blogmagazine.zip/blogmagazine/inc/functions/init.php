<?php
/*
 * Require sanitize function
 */
require_once blogmagazine_file_directory('inc/functions/sanitize.php');

/*
 * Require customizer function
 */
require_once blogmagazine_file_directory('inc/functions/customizer.php');

/*
 * Require Template Tags
 */
require_once blogmagazine_file_directory('inc/functions/template-functions.php');


/*
 * Require Template Tags
 */
require_once blogmagazine_file_directory('inc/functions/template-tags.php');
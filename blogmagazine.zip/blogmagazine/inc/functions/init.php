<?php
/*
 * Require sanitize function
 */
require_once blogmagazine_file_directory('inc/functions/sanitize.php');

/*
 * Require Template Tags
 */
require_once blogmagazine_file_directory('inc/functions/template-functions.php');


/*
 * Require Template Tags
 */
require_once blogmagazine_file_directory('inc/functions/template-tags.php');